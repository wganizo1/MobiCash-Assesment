package com.ads.mobicashassesement;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;

import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.os.Handler;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.snackbar.Snackbar;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.ads.mobicashassesement.SQLiteAdapter.EMAIL;
import static com.ads.mobicashassesement.SQLiteAdapter.IDD;
import static com.ads.mobicashassesement.SQLiteAdapter.MOBILE;
import static com.ads.mobicashassesement.SQLiteAdapter.NAME;
import static com.ads.mobicashassesement.SQLiteAdapter.PASSWORD;

    public class Dashboard extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener{
    public SQLiteAdapter mySQLiteAdapter;
    public String my_name,my_email,my_password,my_mobile,my_status;
    public TextView sqlite_grid_label;
    public  GridView gv;
    public String URL ="https://alterbliss.co.za/mobi_cash/index.php";
    public static final String JSON_ARRAY = "result";
    private JSONArray servr_resp = null;
    public static String[] u_name;
    public static String[] u_mobile;
    public static String[] u_id;
    public static String[] u_email;
    public static String[] u_password;
    public DrawerLayout drawer;
    MainActivity m = new MainActivity();
    String option;
        @Override
        protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        sqlite_acc();
        sqlite_grid_label = findViewById(R.id.sqlite_grid_label);
        Bundle extras = getIntent().getExtras();
        option = extras.getString("option");
        if(option.equals("Sqlite")) {
        //GRIDVIEW FOR DATA IN SQLITE
        grid_for_sqlite_or_mysql_data(my_name, my_email, my_mobile);
        }
        else if(option.equals("Mysql")) {
        //JSON request with Email and Password is sent and a JSON RESPONSE is recieved
        get_json_from_mysql();
        }
            Toolbar toolbar = findViewById(R.id.toolbar);
            setSupportActionBar(toolbar);
            FloatingActionButton fab = findViewById(R.id.fab);
            fab.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Snackbar.make(view, "MobiCash Assessment", Snackbar.LENGTH_LONG)
                            .setAction("Action", null).show();
                }
            });
            drawer = findViewById(R.id.drawer_layout);
            NavigationView navigationView = findViewById(R.id.nav_view);
            ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                    this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
            drawer.addDrawerListener(toggle);
            toggle.syncState();
            navigationView.setNavigationItemSelectedListener(this);
            mySQLiteAdapter = new SQLiteAdapter(getApplicationContext());
            mySQLiteAdapter.openToRead();

        }

        @Override
        public void onBackPressed() {
        super.onBackPressed();
        finish();
        Intent main_activity = new Intent(getApplicationContext(),MainActivity.class);
        startActivity(main_activity);
        }
    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_home) {

        } else if (id == R.id.view_sqlite_data) {
            //DATA FROM MYSQL
            Intent dashboard = new Intent(getApplicationContext(), Dashboard.class);
            dashboard.putExtra("option","Mysql");
            startActivity(dashboard);
        } else if (id == R.id.nav_register) {
            m.register();
        }else if (id == R.id.nav_dash) {
            if(my_status.equals("0") || my_status.equals("")) {
                m.login();
            }else {
                Intent dashboard = new Intent(getApplicationContext(), Dashboard.class);
                dashboard.putExtra("option","Sqlite");
                startActivity(dashboard);
            }
        }
        else if (id == R.id.nav_login) {
            if(my_status.equals("0") || my_status.equals("")) {
                m.login();
            }else{
                show_toast("You are already Logged in");
            }
        }
        else if (id == R.id.nav_share) {
            Intent sendIntent = new Intent();
            sendIntent.setAction(Intent.ACTION_SEND);
            sendIntent.putExtra(Intent.EXTRA_TEXT, "MobiCash Assessment");
            sendIntent.setType("text/plain");
            sendIntent.setPackage("com.whatsapp");
            startActivity(sendIntent);
        }
        else if (id == R.id.nav_logout) {
            mySQLiteAdapter.openToWrite();
            mySQLiteAdapter.deleteAllusers();
            mySQLiteAdapter.add_user("0", my_name, my_email, my_password, my_mobile);
            restartThisActivity();
        }else if (id == R.id.nav_share) {
            Intent sendIntent = new Intent();
            sendIntent.setAction(Intent.ACTION_SEND);
            sendIntent.putExtra(Intent.EXTRA_TEXT, "Hi");
            sendIntent.setType("text/plain");
            sendIntent.setPackage("com.whatsapp");
            startActivity(sendIntent);

        }

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
        //Method for retrieving sqlite data
        public void sqlite_acc(){
        mySQLiteAdapter = new SQLiteAdapter(getApplicationContext());
        mySQLiteAdapter.openToRead();
        my_name  =   mySQLiteAdapter.get_details(NAME);
        my_email  =   mySQLiteAdapter.get_details(EMAIL);
        my_mobile  =   mySQLiteAdapter.get_details(MOBILE);
        my_password  =   mySQLiteAdapter.get_details(PASSWORD);
        my_status  =   mySQLiteAdapter.get_details(IDD);
        }

        //Method for Showing Grid
        public void grid_for_sqlite_or_mysql_data(String nme,String em, String phone){
        // Get the widgets reference from XML layout
        gv = findViewById(R.id.my_account);
        sqlite_grid_label.setText("User Account Details From The "+option+" Database Captured on Registration");

        // Initializing a new String Array
        String[] plants = new String[]{
        "NAME",
        "EMAIL",
        "MOBILE",
        nme,
        em,
        phone
        };

        // Populate a List from Array elements
        final List<String> sqlite_acc_details = new ArrayList<>(Arrays.asList(plants));

        // Data bind GridView with ArrayAdapter (String Array elements)
        gv.setAdapter(new ArrayAdapter<String>(
        this, android.R.layout.simple_list_item_1, sqlite_acc_details) {
        public View getView(int position, View convertView, ViewGroup parent) {

        // Return the GridView current item as a View
        View view = super.getView(position, convertView, parent);

        // Convert the view as a TextView widget
        TextView textViewItem = (TextView) view;

        // set the TextView text color (GridView item color)
        textViewItem.setTextColor(Color.DKGRAY);

        // Set the layout parameters for TextView widget
        RelativeLayout.LayoutParams lp = new RelativeLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        );
        textViewItem.setLayoutParams(lp);

        // Get the TextView LayoutParams
        RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams) textViewItem.getLayoutParams();

        // Set the width of TextView widget (item of GridView)
        params.width = getPixelsFromDPs(Dashboard.this, 120);

        // Set the TextView height (GridView item/row equal height)
        params.height = getPixelsFromDPs(Dashboard.this,50);

        // Set the TextView layout parameters
        textViewItem.setLayoutParams(params);

        // Display TextView text in center position
        textViewItem.setGravity(Gravity.CENTER);

        // Set the TextView text font family and text size
        textViewItem.setTypeface(Typeface.SANS_SERIF, Typeface.NORMAL);
        textViewItem.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 12);

        // Set the TextView text (GridView item text)
        textViewItem.setText(sqlite_acc_details.get(position));

        // Set the TextView background color
        textViewItem.setBackgroundColor(Color.parseColor("#000000"));
        textViewItem.setTextColor(Color.parseColor("#ffffff"));
        // Return the TextView widget as GridView item
        return textViewItem;
        }
        });
        }

        // Method for converting DP value to pixels
        public static int getPixelsFromDPs(Activity activity, int dps){
        Resources r = activity.getResources();
        int  px = (int) (TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP, dps, r.getDisplayMetrics()));
        return px;
        }

        //Mysql JSON Request and Response
        public void get_json_from_mysql(){

        try{
        StringRequest stringRequest = new StringRequest(Request.Method.POST, URL,
        new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                JSONObject jsonObject=null;

                try {
                    jsonObject = new JSONObject(response);
                    servr_resp = jsonObject.getJSONArray(JSON_ARRAY);
                    u_name = new String[servr_resp.length()];
                    u_email = new String[servr_resp.length()];
                    u_id = new String[servr_resp.length()];
                    u_mobile = new String[servr_resp.length()];
                    u_password = new String[servr_resp.length()];
                    for (int i = 0; i < servr_resp.length(); i++) {
                        try {
                            JSONObject jo = servr_resp.getJSONObject(i);
                            u_id[i] = jo.getString("id");
                            u_name[i] = jo.getString("name");
                            u_email[i] = jo.getString("email");
                            u_mobile[i] = jo.getString("mobile");
                            u_password[i] = jo.getString("password");
                        }
                        catch (Exception e) {
                            show_toast("COMMUNICATION ERROR!!!");
                        }
                        //GRIDVIEW FOR DATA IN SQLITE
                        grid_for_sqlite_or_mysql_data(u_name[0],u_email[0],u_mobile[0]);

                    }
                } catch (JSONException e) {
                    show_toast("COMMUNICATION ERROR!!!");
                    e.printStackTrace();
                }
            }
        },
        new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                show_toast("COMMUNICATION ERROR!!!");
            }
        })
{
    @Override
    protected Map<String, String> getParams() {
        Map<String, String> params = new HashMap<String, String>();
        params.put("required_action", "Login");
        params.put("email", my_email);
        params.put("password", my_password);
        return params;
    }

    };

    RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
    requestQueue.add(stringRequest);
    }catch (Exception e){
    // loading.dismiss();
    show_toast("COMMUNICATION ERROR!!!");
    }

    }
    //Method for Toast
    public void show_toast(String msg){
    Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
    private void restartThisActivity()
    {
        Intent i = getApplicationContext().getPackageManager()
                .getLaunchIntentForPackage(getApplicationContext().getPackageName() );

        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK );
        startActivity(i);
    }

    }



