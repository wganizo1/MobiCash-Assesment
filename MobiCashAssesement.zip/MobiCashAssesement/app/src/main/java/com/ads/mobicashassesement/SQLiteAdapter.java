package com.ads.mobicashassesement;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class SQLiteAdapter  {

	public static final String DATABASE_NAME = "mobicash";
	public static final String TABLE_NAME = "user";
	public static final String IDD = "idd";
	public static final String NAME="name";
	public static final String PASSWORD="password";
	public static final String EMAIL ="email";
	public static final String MOBILE="mobile";
	public int index_ITEM;
	public SQLiteDatabase sqLiteDatabase;
	public SQLiteHelper sqLiteHelper;
	public Context context;
	MainActivity main = new MainActivity();

	private static final String SCRIPT_CREATE_TBLEUSER = "create table " + TABLE_NAME + " ("+"'id' INTEGER PRIMARY KEY AUTOINCREMENT" +","+IDD+","+ NAME +","+ EMAIL +","+PASSWORD+","+MOBILE+")";


	public SQLiteAdapter(Context c){
		context = c;
	}


	public SQLiteAdapter openToRead() throws android.database.SQLException {
		sqLiteHelper = new SQLiteHelper(context, DATABASE_NAME, null, 1);
		sqLiteDatabase = sqLiteHelper.getReadableDatabase();
		return this;
	}

	public SQLiteAdapter openToWrite() throws android.database.SQLException {

		sqLiteHelper = new SQLiteHelper(context, DATABASE_NAME, null, 1);
		sqLiteDatabase = sqLiteHelper.getWritableDatabase();
		return this;

	}



	public int deleteAllusers() {
			return sqLiteDatabase.delete(TABLE_NAME, null, null);
		}

		public long add_user(String id, String name, String email, String pass, String mobile) {
			ContentValues contentValues = new ContentValues();
			contentValues.put(IDD, id);
			contentValues.put(NAME, name);
			contentValues.put(EMAIL, email);
			contentValues.put(PASSWORD, pass);
			contentValues.put(MOBILE, mobile);
			return sqLiteDatabase.insert(TABLE_NAME, null, contentValues);
		}



	public String get_details(String column_name){
		String[] columns = new String[]{IDD, NAME, EMAIL,PASSWORD,MOBILE};
		Cursor cursor = sqLiteDatabase.query(TABLE_NAME, columns,
				null, null, null, null, null);
		String result = "";

		index_ITEM = cursor.getColumnIndex(column_name);

		for(cursor.moveToFirst(); !(cursor.isAfterLast()); cursor.moveToNext()){

			result = result + cursor.getString(index_ITEM);
		}

		return result;
	}

	public class SQLiteHelper extends SQLiteOpenHelper {

		public SQLiteHelper(Context context, String name,
							SQLiteDatabase.CursorFactory factory, int version) {
			super(context, name, factory, version);
		}

		@Override
		public void onCreate(SQLiteDatabase db) {
			// TODO Auto-generated method stub
			db.execSQL(SCRIPT_CREATE_TBLEUSER);

		}

		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {



		}

	}
}




