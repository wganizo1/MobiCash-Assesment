package com.ads.mobicashassesement;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.snackbar.Snackbar;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import static com.ads.mobicashassesement.SQLiteAdapter.EMAIL;
import static com.ads.mobicashassesement.SQLiteAdapter.IDD;
import static com.ads.mobicashassesement.SQLiteAdapter.MOBILE;
import static com.ads.mobicashassesement.SQLiteAdapter.NAME;
import static com.ads.mobicashassesement.SQLiteAdapter.PASSWORD;

public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {
    public SQLiteAdapter mySQLiteAdapter;
    public String login_email,login_password,str_verify_pass,str_fname,str_email,str_password,str_mobile,my_name,my_email,my_password,my_mobile,my_status;
    private TextView textViewWelcome,sqlite_grid_label;
    public GridView sqlite_acc,mysql_acc;
    public String URL ="https://alterbliss.co.za/mobi_cash/index.php";
    public static final String JSON_ARRAY = "result";
    private JSONArray servr_resp = null;
    public DrawerLayout drawer;
    public static String[] u_name;
    public static String[] u_mobile;
    public static String[] u_id;
    public static String[] u_email;
    public static String[] u_password;
    public GridView gv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
         mySQLiteAdapter = new SQLiteAdapter(getApplicationContext());
         sqlite_acc = findViewById(R.id.my_account);
         mysql_acc = findViewById(R.id.my_account);
         textViewWelcome = findViewById(R.id.textViewWelcome);
         sqlite_grid_label = findViewById(R.id.sqlite_grid_label);
         mySQLiteAdapter = new SQLiteAdapter(getApplicationContext());
         mySQLiteAdapter.openToRead();
         //Retrieving sqlite Data
         sqlite_acc();
         //Check if user is registered and logged in
            welcome();
            Toolbar toolbar = findViewById(R.id.toolbar);
            setSupportActionBar(toolbar);
            FloatingActionButton fab = findViewById(R.id.fab);
            fab.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Snackbar.make(view, "MobiCash Assessment", Snackbar.LENGTH_LONG)
                            .setAction("Action", null).show();
                }
            });
            drawer = findViewById(R.id.drawer_layout);
            NavigationView navigationView = findViewById(R.id.nav_view);
            ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                    this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
            drawer.addDrawerListener(toggle);
            toggle.syncState();
            navigationView.setNavigationItemSelectedListener(this);

            drawer.openDrawer(Gravity.LEFT);
            mySQLiteAdapter = new SQLiteAdapter(getApplicationContext());
            mySQLiteAdapter.openToRead();
            final Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    drawer.closeDrawer(Gravity.LEFT);
                }
            }, 2000);
        }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_home) {

        } else if (id == R.id.view_sqlite_data) {
            //DATA FROM MYSQL
            Intent dashboard = new Intent(getApplicationContext(), Dashboard.class);
            dashboard.putExtra("option","Mysql");
            startActivity(dashboard);
        } else if (id == R.id.nav_register) {
            register();
        }else if (id == R.id.nav_dash) {
            if(my_status.equals("0") || my_status.equals("")) {
                login();
            }else {
                Intent dashboard = new Intent(getApplicationContext(), Dashboard.class);
                dashboard.putExtra("option","Sqlite");
                startActivity(dashboard);
            }
        }
         else if (id == R.id.nav_login) {
            if(my_status.equals("0") || my_status.equals("")) {
                login();
            }else{
                show_toast("You are already Logged in");
            }
        }
        else if (id == R.id.nav_share) {
            Intent sendIntent = new Intent();
            sendIntent.setAction(Intent.ACTION_SEND);
            sendIntent.putExtra(Intent.EXTRA_TEXT, "MobiCash Assessment");
            sendIntent.setType("text/plain");
            sendIntent.setPackage("com.whatsapp");
            startActivity(sendIntent);
        }
        else if (id == R.id.nav_logout) {
            mySQLiteAdapter.openToWrite();
            mySQLiteAdapter.deleteAllusers();
            mySQLiteAdapter.add_user("0", my_name, my_email, my_password, my_mobile);
            restartThisActivity();
        }else if (id == R.id.nav_share) {
            Intent sendIntent = new Intent();
            sendIntent.setAction(Intent.ACTION_SEND);
            sendIntent.putExtra(Intent.EXTRA_TEXT, "Hi");
            sendIntent.setType("text/plain");
            sendIntent.setPackage("com.whatsapp");
            startActivity(sendIntent);

        }

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    //Method for Login by getting a JSON RESPONSE for Mysql
    public void login(){
        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);
        LayoutInflater inflater = this.getLayoutInflater();
        final View dialogView = inflater.inflate(R.layout.login, null);
        dialogBuilder.setView(dialogView);

        final EditText email = dialogView.findViewById(R.id.email);
        final EditText password = dialogView.findViewById(R.id.password);

        dialogBuilder.setTitle("LOGIN");
        dialogBuilder.setIcon(R.drawable.profile);
        dialogBuilder.setPositiveButton("REGISTER", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {
                register();
            }
        });
        dialogBuilder.setNeutralButton("CANCEL", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {
                finish();
            }
        });
        dialogBuilder.setNegativeButton("LOGIN", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {
        login_email = email.getText().toString();
        login_password= password.getText().toString();
        if(login_password.length()<6){
            show_toast("Check your Password");
        }
        else if(isValidEmailId(login_email)) {
            sqlite_acc();
            try {
                StringRequest stringRequest = new StringRequest(Request.Method.POST, URL,
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                JSONObject jsonObject = null;

                                try {
                                    jsonObject = new JSONObject(response);
                                    servr_resp = jsonObject.getJSONArray(JSON_ARRAY);
                                    u_name = new String[servr_resp.length()];
                                    u_email = new String[servr_resp.length()];
                                    u_id = new String[servr_resp.length()];
                                    u_mobile = new String[servr_resp.length()];
                                    u_password = new String[servr_resp.length()];
                                    for (int i = 0; i < servr_resp.length(); i++) {
                                        try {
                                            JSONObject jo = servr_resp.getJSONObject(i);
                                            u_id[i] = jo.getString("id");
                                            u_name[i] = jo.getString("name");
                                            u_email[i] = jo.getString("email");
                                            u_mobile[i] = jo.getString("mobile");
                                            u_password[i] = jo.getString("password");
                                        } catch (Exception e) {
                                            show_toast(e.toString());
                                        }
                                        try {
                                            if (u_email[0].equals(login_email) && u_password[0].equals(login_password)) {
                                                show_toast("LOGIN SUCCESSFUL");
                                                mySQLiteAdapter.openToWrite();
                                                mySQLiteAdapter.deleteAllusers();
                                                mySQLiteAdapter.add_user("1", u_name[0], u_email[0], u_password[0], u_mobile[0]);
                                                welcome();
                                            } else {
                                                show_toast("LOGIN FAILED");
                                                login();
                                            }
                                        } catch (Exception e) {
                                            show_toast("Login Failed");
                                        }
                                    }
                                } catch (JSONException e) {
                                    show_toast("COMMUNICATION ERROR!!!");
                                    e.printStackTrace();
                                }
                            }
                        },
                        new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                show_toast("COMMUNICATION ERROR!!!");
                            }
                        }) {
                    @Override
                    protected Map<String, String> getParams() {
                        Map<String, String> params = new HashMap<String, String>();
                        params.put("email", login_email);
                        params.put("password", login_password);
                        params.put("required_action", "Login");
                        return params;
                    }

                };

                RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
                requestQueue.add(stringRequest);
            } catch (Exception e) {
                // loading.dismiss();
                show_toast("COMMUNICATION ERROR!!!");
            }

    } else{
            show_toast("Invalid Email");
            login();
        }
    }
    });
    AlertDialog b = dialogBuilder.create();
    b.setCancelable(false);
    b.show();
    }

    //Method for User Registration on Sqlite and Posting JSON REQUEST to MYSQL
    public void register(){
        final AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);
        LayoutInflater inflater = this.getLayoutInflater();
        final View dialogView = inflater.inflate(R.layout.register, null);
        dialogBuilder.setView(dialogView);
        final EditText editText_name,editText_email,editText_passwrd,editText_verify_password,editText_mobile;

         editText_name = dialogView.findViewById(R.id.name);
         editText_mobile = dialogView.findViewById(R.id.mobile);
         editText_email = dialogView.findViewById(R.id.email);
         editText_passwrd = dialogView.findViewById(R.id.password);
         editText_verify_password = dialogView.findViewById(R.id.verify_password);
         dialogBuilder.setTitle("LOGIN");
         dialogBuilder.setIcon(R.drawable.profile);
         if(my_status.equals("1")){
             sqlite_acc();
             dialogBuilder.setMessage("You are currently registered and logged in as "+my_name+"\n" +
                     "By Registering, a new account will be created for your device");
         }
         dialogBuilder.setPositiveButton("REGISTER", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {
                str_fname = editText_name.getText().toString();
                str_email = editText_email.getText().toString();
                str_password = editText_passwrd.getText().toString();
                str_mobile = editText_mobile.getText().toString();
                str_verify_pass = editText_verify_password.getText().toString();
                textViewWelcome.setText("");

                //Registration Input Validation
                if(str_password.length()<6){
                    show_toast("Your Password is too short");
                    register();
                }
                else if(!str_fname.contains(" ")){
                    show_toast("Please Enter a Fullname");
                }
                else if(!str_password.equals(str_verify_pass)){
                    show_toast("Password Mismatch");
                    register();
                }
                else if(!isValidEMobile(str_mobile)){
                    show_toast("Invalid Mobile Number");
                    register();
                }
                else if(!isValidEmailId(str_email)){
                    show_toast("Invalid Email");
                    register();
                }
                else {
                    mySQLiteAdapter.openToWrite();
                    mySQLiteAdapter.deleteAllusers();
                    mySQLiteAdapter.add_user("1", str_fname, str_email, str_password, str_mobile);
                    sqlite_acc();
                    save_user_to_mysql_onServer();
                }
            }

        });


        dialogBuilder.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {
               login();
            }
        });
        AlertDialog b = dialogBuilder.create();
        b.setCancelable(false);
        b.show();
    }

    //Method for Toast
    public void show_toast(String msg){
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    //Method to check user login status
    public void welcome(){
        try{
        mySQLiteAdapter.openToRead();
        sqlite_acc();
        if(my_status.equals("1")){
            //DATA FROM MYSQL
            gv = findViewById(R.id.my_account);
            sqlite_and_mysql_data_grid(u_name[0],u_email[0],u_mobile[0]);
        }
        else {
            show_toast("Please Login");
            login();
        }
    }catch (Exception e) {
    }
  }
  //Method to get Sqlite data
  public void sqlite_acc(){
      mySQLiteAdapter.openToRead();
      my_name  =   mySQLiteAdapter.get_details(NAME);
      my_email  =   mySQLiteAdapter.get_details(EMAIL);
      my_mobile  =   mySQLiteAdapter.get_details(MOBILE);
      my_password  =   mySQLiteAdapter.get_details(PASSWORD);
      my_status  =   mySQLiteAdapter.get_details(IDD);
  }

    //Method for Displaying Data in Grid
    public void sqlite_and_mysql_data_grid(String nme, String em, String phn){
        // Get the widgets reference from XML layout

        sqlite_grid_label.setText("User Account Details From The Local MYSQL Database Captured on Registration");
        // Initializing a new String Array
        String[] sqlite_user_details_array = new String[]{
                "NAME",
                "EMAIL",
                "MOBILE",
                nme,
                em,
                phn
        };

        // Populate a List from Array elements
        final List<String> sqlite_acc_details = new ArrayList<>(Arrays.asList(sqlite_user_details_array));

        // Data bind GridView with ArrayAdapter (String Array elements)
        gv.setAdapter(new ArrayAdapter<String>(
                this, android.R.layout.simple_list_item_1, sqlite_acc_details) {
            public View getView(int position, View convertView, ViewGroup parent) {

                // Return the GridView current item as a View
                View view = super.getView(position, convertView, parent);

                // Convert the view as a TextView widget
                TextView textViewItem = (TextView) view;

                // set the TextView text color (GridView item color)
                textViewItem.setTextColor(Color.DKGRAY);

                // Set the layout parameters for TextView widget
                RelativeLayout.LayoutParams lp = new RelativeLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
                );
                textViewItem.setLayoutParams(lp);

                // Get the TextView LayoutParams
                RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams) textViewItem.getLayoutParams();

                // Set the width of TextView widget (item of GridView)
                params.width = getPixelsFromDPs(MainActivity.this, 120);

                // Set the TextView height (GridView item/row equal height)
                params.height = getPixelsFromDPs(MainActivity.this,50);

                // Set the TextView layout parameters
                textViewItem.setLayoutParams(params);

                // Display TextView text in center position
                textViewItem.setGravity(Gravity.CENTER);

                // Set the TextView text font family and text size
                textViewItem.setTypeface(Typeface.SANS_SERIF, Typeface.NORMAL);
                textViewItem.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 12);

                // Set the TextView text (GridView item text)
                textViewItem.setText(sqlite_acc_details.get(position));

                // Set the TextView background color
                textViewItem.setBackgroundColor(Color.parseColor("#000000"));
                textViewItem.setTextColor(Color.parseColor("#ffffff"));
                // Return the TextView widget as GridView item
                return textViewItem;
            }
        });
    }

    // Method for converting DP value to pixels
    public static int getPixelsFromDPs(Activity activity, int dps){
        Resources r = activity.getResources();
        int  px = (int) (TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP, dps, r.getDisplayMetrics()));
        return px;
    }

    //JSON Request to save user on Mysql
    public void save_user_to_mysql_onServer(){
        try {
            StringRequest stringRequest = new StringRequest(Request.Method.POST, URL,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            try {
                                if(response.equals("Registration Successful")){
                                    login();
                                }
                                else {
                                    show_toast(response);
                                    register();
                                }
                            } catch (Exception e) {
                                show_toast("COMMUNICATION ERROR!!!");
                                e.printStackTrace();
                            }
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            show_toast("COMMUNICATION ERROR!!!");
                        }
                    })
            {
                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<String, String>();
                    params.put("email", my_email);
                    params.put("password", my_password);
                    params.put("name", my_name);
                    params.put("mobile", my_mobile);
                    params.put("required_action", "Register");
                    return params;
                }

            };

            RequestQueue requestQueue = Volley.newRequestQueue(this);
            requestQueue.add(stringRequest);
        }catch (Exception e){
            show_toast("COMMUNICATION ERROR!!!");
        }
    }
    public void restartThisActivity()
    {
        Intent i = getApplicationContext().getPackageManager()
                .getLaunchIntentForPackage(getApplicationContext().getPackageName() );

        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK );
        startActivity(i);
    }

    //Email Validation Method
    private boolean isValidEmailId(String email){

        return Pattern.compile("^(([\\w-]+\\.)+[\\w-]+|([a-zA-Z]{1}|[\\w-]{2,}))@"
                + "((([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\.([0-1]?"
                + "[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\."
                + "([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\.([0-1]?"
                + "[0-9]{1,2}|25[0-5]|2[0-4][0-9])){1}|"
                + "([a-zA-Z]+[\\w-]+\\.)+[a-zA-Z]{2,4})$").matcher(email).matches();
    }

    //Mobile Validation Method
    private boolean isValidEMobile(String mobil){

        return Pattern.compile("^\\+?\\(?[0-9]{1,3}\\)? ?-?[0-9]{1,3} ?-?[0-9]{3,5} ?-?[0-9]{4}( ?-?[0-9]{3})?").matcher(mobil).matches();
    }

}




